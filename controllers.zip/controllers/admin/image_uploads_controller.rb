class Admin::ImageUploadsController < ApplicationController
  before_action :set_image_upload, only: %i[ show edit update  ]

  # GET /image_uploads or /image_uploads.json
  def index
    begin
    @image_uploads = ImageUpload.all.limit(30)
    @count = ImageUpload.count()
    @my_array = []
    s3 = Aws::S3::Resource.new
    bucket_name = 'stryker-social'

    @image_uploads.each do |image_url|
    uri = URI.parse(image_url.image_name)
    key = File.basename(uri.path)
     @image_objects = s3.bucket(bucket_name).object(key.to_s)
     @my_array.push({image:@image_objects , id:image_url.id})
    end
  
     rescue => e
      render json: { errors:e.message }, status: :unprocessable_entity
     end
  end

 

  def load_more
    @my_array = []
    offset = params[:offset].to_i
    s3 = Aws::S3::Resource.new
    bucket_name = 'stryker-social'
    @image_uploads = ImageUpload.all.offset(offset).limit(10) # Load more items
    @image_uploads.each do |image_url|
      uri = URI.parse(image_url.image_name)
      key = File.basename(uri.path)       
      @image_objects = s3.bucket(bucket_name).object(key.to_s)
      @my_array.push({ image: @image_objects.presigned_url(:get),key: @image_objects.key , id: image_url.id })
    end
    
      render json: @my_array.as_json
  end
  

  # GET /image_uploads/1 or /image_uploads/1.json
  def show
  
  end

  # GET /image_uploads/new
  def new
    @image_upload = ImageUpload.new
  end

  # GET /image_uploads/1/edit
  def edit
  end

  # POST /image_uploads or /image_uploads.json
  def create
    begin
    @image = ImageUpload.new()
     image_path = fileupload(params[:file])    
    @image.update_attribute(:image_name, image_path)
    if @image.save
      render json: { message: "Image created successfully" }, status: :created
    else
      render json: { errors: @image.errors.full_messages }, status: :unprocessable_entity
    end
    rescue => e
    render json: { errors:e.message }, status: :unprocessable_entity
    end
  end

  # GET /get_image_uploads_data
  def get_image_uploads_data
    begin
    image_uploads = ImageUpload.datatable_filter(params["search"]["value"], params["columns"])
    image_uploads_filtered = image_uploads.count
    image_uploads = image_uploads.datatable_order(params["order"]["0"]["column"].to_i,
                                  params["order"]["0"]["dir"])
    image_uploads = image_uploads.offset(params[:start]).limit(params[:length])
    render json: { data: image_uploads,
                   draw: params["draw"].to_i,
                   recordsTotal: ImageUpload.count,
                   recordsFiltered: image_uploads_filtered }
    rescue => e
      render json: { errors:e.message }, status: :unprocessable_entity
    end
  end


  # PATCH/PUT /image_uploads/1 or /image_uploads/1.json
  def update
    begin
    respond_to do |format|
      if @image_upload.update(image_upload_params)
        format.html { redirect_to image_upload_url(@image_upload), notice: "Image upload was successfully updated." }
        format.json { render :show, status: :ok, location: @image_upload }
      else
        format.html { render :edit, status: :unprocessable_entity }
        format.json { render json: @image_upload.errors, status: :unprocessable_entity }
      end
    end
     rescue => e
      render json: { errors:e.message }, status: :unprocessable_entity
     end
  end

  # DELETE /image_uploads/1 or /image_uploads/1.json
  # Delete the object using S3 Bucket 
  def delete_image
    begin
    if  params[:id].present?
      key_id= params[:id].split('-',2)
      @image_upload = ImageUpload.find_by(id: key_id[0].to_i)
      s3 = Aws::S3::Resource.new
      bucket_name = 'stryker-social'
      @s3_object = s3.bucket(bucket_name).object(key_id[1])
      begin
        @s3_object.delete
        @image_upload.destroy
      rescue Aws::S3::Errors::NoSuchKey
      rescue StandardError => e
      end
      respond_to do |format|
        format.html { redirect_to request.referer , notice: "Image successfully deleted !" }
        format.json { head :no_content }
      end
    end
     rescue => e
      render json: { errors:e.message }, status: :unprocessable_entity
     end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_image_upload
      begin
      @image_upload = ImageUpload.find(params[:id])
       rescue => e
      render json: { errors:e.message }, status: :unprocessable_entity
     end
    end

    # Only allow a list of trusted parameters through.
    def image_upload_params
      params.require(:image_upload).permit(:title, :description, :image_name, :guide, :created_at, :updated_at, :deleted_at)
    end
end
