class Admin::FacebookPostsController < ApplicationController
  before_action :set_facebook_post, only: %i[ show edit update destroy ]

  # GET /facebook_posts or /facebook_posts.json
  def index
    begin
    @facebook_post = FacebookPost.new
    
    @image_uploads = ImageUpload.all.limit(30)
    @count = ImageUpload.count()
    @my_array = []
    @event_array = []
    s3 = Aws::S3::Resource.new
    bucket_name = 'stryker-social'

      @image_uploads.each do |image_url|
      uri = URI.parse(image_url.image_name)
      key = File.basename(uri.path)
      @image_objects = s3.bucket(bucket_name).object(key.to_s)
      @my_array.push({image:@image_objects , id:image_url.id})
      end


      @add_event = FacebookPost.all
      @add_event.each do |image_ids|
        ids_to_search = image_ids.image_upload.split(',').map(&:to_i)
        image_uploads = ImageUpload.where(id: ids_to_search)
        
        image_uploads.each do |image_url|
        uri = URI.parse(image_url.image_name)
        key = File.basename(uri.path)
        image_objects = s3.bucket(bucket_name).object(key.to_s)
        @event_array.push({images:[image_objects.presigned_url(:get, expires_in: nil)] , id:image_ids.id, start: image_ids.post_date })
      end 
      @event =@event_array.to_json
      
    end 
    rescue => e
      render json: { errors:e.message }, status: :unprocessable_entity
     end
  end
          

  # GET /facebook_posts/1 or /facebook_posts/1.json
  def show
  end

  # GET /facebook_posts/new
  def new
    @facebook_post = FacebookPost.new
  end

  # GET /facebook_posts/1/edit
  def edit
      render json: {data: @facebook_post }, status: :ok
  end

  # POST /facebook_posts or /facebook_posts.json
  def create
    begin
    @facebook_post = FacebookPost.new(facebook_post_params) 
    @facebook_post.update_attribute(:post_frequency, params[:post_frequency].to_i)
    @facebook_post.save
  rescue => e
    render json: { errors:e.message }, status: :unprocessable_entity
   end
  end

  # PATCH/PUT /facebook_posts/1 or /facebook_posts/1.json
  def update
    begin
      if @facebook_post.update(facebook_post_params)
        render json: {response:{data: @facebook_post }, status: :ok}
      else
        # format.html { render :edit, status: :unprocessable_entity }
        # format.json { render json: @facebook_post.errors, status: :unprocessable_entity }
      end
    rescue => e
      render json: { errors:e.message }, status: :unprocessable_entity
     end
  end

  # DELETE /facebook_posts/1 or /facebook_posts/1.json
  def destroy
    begin
    if @facebook_post.destroy
      render json: { status: :ok, notice:"Deleted" }
    else
      render json: { status: :not_found, notice:@facebook_post.errors }
    end
     rescue => e
      render json: { errors:e.message }, status: :unprocessable_entity
     end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_facebook_post
      begin
      @facebook_post = FacebookPost.find(params[:id])
       rescue => e
      render json: { errors:e.message }, status: :unprocessable_entity
     end
    end

    # Only allow a list of trusted parameters through.
    def facebook_post_params
      params.permit(:description, :repeat_cycle ,:image_upload,:post_date)
      end
end
