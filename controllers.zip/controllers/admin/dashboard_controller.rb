class Admin::DashboardController < ApplicationController
  before_action :authenticate_user!

  def index
    @users = User.where(users: { deleted_at: nil, role: 1 }).count
    # Get the number of users with role 2
    @all_users = User.count("id")
  end

  def show
  end

  def set_path
    if request.ssl?
      # Set the path for HTTPS requests
      @path = "https://" + request.host + request.fullpath
    else
      # Set the path for HTTP requests
      @path = "http://" + request.host + request.fullpath
    end
  end
end
