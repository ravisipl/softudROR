class Admin::UsersController < ApplicationController
  before_action :authenticate_user!
  load_and_authorize_resource

  def index
     begin
    #@users = User.all
    @users = User.where(deleted_at: nil)
    rescue => e
      render json: { errors:e.message }, status: :unprocessable_entity
     end
  end

  # GET /users/{username}
  def show
    begin
    @users = User.find(params[:id])
    readNotification(params[:id], "user_onborading")
    rescue => e
      render json: { errors:e.message }, status: :unprocessable_entity
     end
  end

  def edit
    @users = User.find(params[:id])
  end

  def   
    begin
    users = User.datatable_filter(params["search"]["value"], params["columns"])
    users_filtered = users.count
    users = users.datatable_order(params["order"]["0"]["column"].to_i,
                                  params["order"]["0"]["dir"])
    users = users.offset(params[:start]).limit(params[:length])

    render json: { data: users,
                   draw: params["draw"].to_i,
                   recordsTotal: User.count,
                   recordsFiltered: users_filtered }
    rescue => e
    render json: { errors:e.message }, status: :unprocessable_entity
  end
  end

  def update
    begin
    @users = User.find(params[:id])
    if @users.update(user_params)
      flash.notice = "User Successfully Updated"
      redirect_to admin_users_path
    else
      redirect_to edit_admin_user_path
    end
      rescue => e
      render json: { errors:e.message }, status: :unprocessable_entity
     end
  end

  def userprofile
    @users = User.find(current_user.id)
  end

  def profile_update
    begin
    @users = User.find(params[:id])
    if params[:user][:profile_image_url].present?
      image = params[:user][:profile_image_url]
      image_path = adminProfileImageUpload(image)
      @users.update_attribute(:image_url, image_path)
    end
    if params[:user][:password] != params[:user][:password_confirmation]
      flash.alert = "Password not match with Confirm Password"
      redirect_to admin_userprofile_path
    elsif @users.update(profile_user_params)
      flash.notice = "User Successfully Updated"
      redirect_to admin_userprofile_path
    else
      redirect_to admin_userprofile_path
    end
      rescue => e
      render json: { errors:e.message }, status: :unprocessable_entity
     end
  end

  def profile_image_remove
    begin
    @users = User.find(params[:id])
    @users.image_url = nil
    @users.save
    redirect_to admin_userprofile_path
      rescue => e
      render json: { errors:e.message }, status: :unprocessable_entity
     end
  end

  def destroy
    begin
    @user = User.find(params[:id])
    if @user.destroy
      flash.notice = "User destroyed Successfully!"
      redirect_to admin_users_path
    else
      flash.alert = "User couldn't be destroyed, there has been some issue!"
      redirect_to admin_users_path
    end
      rescue => e
      render json: { errors:e.message }, status: :unprocessable_entity
     end
  end

  def new
    begin
    @user = User.new
    @user.build_admin_coach_details
      rescue => e
      render json: { errors:e.message }, status: :unprocessable_entity
     end
  end

  def create
    begin
    @user = User.new(user_params)
    if @user.save
      flash.notice = "Successfully saved"
    else
      flash.alert = "There has been some error please try again later"
    end
    redirect_to admin_users_path
      rescue => e
      render json: { errors:e.message }, status: :unprocessable_entity
     end
  end

  private

  def user_params
    params.require(:users).permit(:first_name, :last_name, :email, :password, :password_confirmation, :contact_number, :gender, :profile_picture)
  end

  def profile_user_params
    params.require(:user).permit(:username, :first_name, :last_name, :email, :password, :password_confirmation, :contact_number)
  end
