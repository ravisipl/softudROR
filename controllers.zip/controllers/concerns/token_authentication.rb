# app/controllers/concerns/token_authentication.rb

module TokenAuthentication
  extend ActiveSupport::Concern

  included do
    before_action :check_token_expiry
  end

  private

  def check_token_expiry
    token = request.headers["Authorization"]&.split(" ")&.last
    return unless token
    userCheck = User.select("id").where(reset_password_token: token).where(deleted_at: nil).first
    userToken = User.select("id").where(reset_password_token: token).first
    if userToken.nil?
      render json: { error: "Someone is login with your credentials" }, status: :unauthorized
    elsif userCheck.nil?
      render json: { error: "Your account is deleted contact to administrator" }, status: :unauthorized
    else
      user = User.select("id").where(reset_password_token: token).where(status: 1).first
      return unless user.nil?
      render json: { error: "Your account has been deactivated" }, status: :unauthorized
    end
  end
end
