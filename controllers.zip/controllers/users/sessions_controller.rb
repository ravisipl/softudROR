class Users::SessionsController < Devise::SessionsController
  layout "login"

  def after_sign_in_path_for(user)
    case user.role
    when "super_admin"
      admin_dashboard_index_path
    else
      reset_session
      flash.alert = "You are not authorized to log in as an admin."
      request.base_url
    end
  end

  def new
    @page_title = "Sign In"
    super
  end
end
