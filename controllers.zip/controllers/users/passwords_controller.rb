class Users::PasswordsController < Devise::PasswordsController
  layout "login"
end
