class ApplicationController < ActionController::Base 
    include CommonHelper
    include Pagination
    # before_action :configure_permitted_parameters, if: :devise_controller?
    protect_from_forgery 
    # helper_method :resource
  
    rescue_from CanCan::AccessDenied do | exception |
        redirect_to root_url, alert: exception.message
    end

    # protected
  
    # def configure_permitted_parameters
    #   devise_parameter_sanitizer.permit(:sign_up) do |u|
    #     u.permit(:email, :phone, :password, :password_confirmation, :uid, :provider)
    #   end
    #   devise_parameter_sanitizer.permit(:sign_in) do |u|
    #     u.permit(:email, :phone, :password, :password_confirmation, :uid, :provider)
    #   end
    #   devise_parameter_sanitizer.permit(:account_update) do |u|
    #     u.permit(:email, :phone, :password, :password_confirmation, :uid, :provider)
    #   end
    # end
    private

    def require_login
      unless logged_in?
        redirect_to login_path, notice: 'Please log in to access this page.'
      end
    end
  
    def logged_in?
      session[:current_user_id].present?
    end 
      
end
