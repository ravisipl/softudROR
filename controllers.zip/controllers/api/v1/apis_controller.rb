class Api::V1::ApisController < ApplicationController
end
